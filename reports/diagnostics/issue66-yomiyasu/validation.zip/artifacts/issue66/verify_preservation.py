"""固定した8段落の採否、本文の範囲、保護対象を照合する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess

root = Path.cwd()
evidence = root / "reports/diagnostics/issue66-yomiyasu"
selection = json.loads((evidence / "selection.json").read_text(encoding="utf-8-sig"))
candidates = json.loads((root / "artifacts/issue66/changes.json").read_text(encoding="utf-8-sig"))
accepted = {c["id"]: c for c in candidates if c["id"] != "debughost-04"}
candidate_by_id = {c["id"]: c for c in candidates}
reasons = {
    "architecture-01": "追跡エンジンの分離と実行体の役割分担を別文にした。構成名と役割は保持した。",
    "architecture-02": "受信条件を保存対象に掛けたまま、別系統での保存と再生・比較の目的を順に示した。『これにより』は直前の保存を指す。",
    "architecture-03": "少なくとも、通常経路、必ず、元のバイト列か復元可能な参照、という範囲と強さが重要なため原文を維持した。",
    "architecture-04": "公式の通信形式の不足と内部フレームの必要性の関係が明確なため原文を維持した。",
    "debughost-01": "アプリケーションの定義と表示確認・任意配信を別文にした。必要に応じて、確認しながら、という条件を保持した。",
    "debughost-02": "内部カウンタの成功とUDP実送信の違い、および設定を併せて判断する依頼を保持した。",
    "debughost-03": "要求できること、既定の起動設定、通常はHTTPS、という限定を保持した。",
    "debughost-04": "試案では文を分けた結果『ます』が3回連続した。原文の因果関係と自然な文末を優先して試案を不採用にした。",
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

result = {"schema_version": 1, "verified_at_utc": datetime.now(timezone.utc).isoformat(), "baseline_head": selection["baseline_head"], "head_at_verification": subprocess.check_output(["git", "rev-parse", "HEAD"]).decode().strip(), "selected_count": 8, "changed_count": 3, "unchanged_count": 5, "scope_note": "本文の変更は選定段落の3行のみ。変更文書には利用者指定のUTF-8 BOMを付け、改行形式を保持した。", "documents": []}
comparison = []
for doc in selection["documents"]:
    path = root / doc["path"]
    base_raw = subprocess.check_output(["git", "show", selection["baseline_head"] + ":" + doc["path"]])
    base_text = base_raw.decode("utf-8-sig").replace("\r\n", "\n")
    expected = base_text
    expected_lines = []
    for para in doc["paragraphs"]:
        assert base_text.splitlines()[para["original_line"] - 1] == para["original_text"]
        final = accepted[para["id"]]["after"] if para["id"] in accepted else para["original_text"]
        if para["id"] in accepted:
            assert expected.count(para["original_text"]) == 1
            expected = expected.replace(para["original_text"], final, 1)
            expected_lines.append(para["original_line"])
        comparison.append({"id": para["id"], "path": doc["path"], "original_line": para["original_line"], "decision": "changed" if para["id"] in accepted else "retained", "before": para["original_text"], "candidate_1": candidate_by_id.get(para["id"], {}).get("after", para["original_text"]), "final": final, "reason": reasons[para["id"]], "human_acceptance": "pending"})
    current_raw = path.read_bytes()
    current_text = current_raw.decode("utf-8-sig").replace("\r\n", "\n")
    assert current_text == expected, doc["path"] + ": 選定範囲外の差分"
    checks = {}
    for label, pattern in {
        "inline_code": r"`[^`\n]+`",
        "fenced_code": r"(?ms)^```[^\n]*\n.*?^```[^\n]*(?:\n|$)",
        "urls": r"https?://[^\s<>]+",
        "ascii_identifiers_and_numbers": r"[A-Za-z0-9_][A-Za-z0-9_:.=/+<>-]*",
    }.items():
        before_tokens = re.findall(pattern, base_text)
        after_tokens = re.findall(pattern, current_text)
        comparison_kind = "multiset" if label == "ascii_identifiers_and_numbers" else "sequence"
        assert (sorted(before_tokens) == sorted(after_tokens) if comparison_kind == "multiset" else before_tokens == after_tokens), doc["path"] + ": " + label
        checks[label] = {"unchanged": True, "count": len(before_tokens), "comparison": comparison_kind}
    changed_lines = [i + 1 for i, (a, b) in enumerate(zip(base_text.splitlines(), current_text.splitlines())) if a != b]
    assert len(base_text.splitlines()) == len(current_text.splitlines())
    assert changed_lines == expected_lines
    final_raw = current_raw if current_raw.startswith(b"\xef\xbb\xbf") else b"\xef\xbb\xbf" + current_raw
    if final_raw != current_raw:
        path.write_bytes(final_raw)
    result["documents"].append({"path": doc["path"], "baseline_git_blob_sha256": sha(base_raw), "baseline_worktree_sha256": doc["original_sha256"], "final_worktree_sha256": sha(final_raw), "content_sha256_normalized_lf_without_bom": sha(current_text.encode("utf-8")), "selected_count": len(doc["paragraphs"]), "changed_lines": changed_lines, "unchanged_outside_selected_lines": True, "line_count": len(current_text.splitlines()), "bom": True, "crlf_count": final_raw.count(b"\r\n"), "lf_count": final_raw.count(b"\n"), "protected_content": checks})
(evidence / "preservation.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8-sig")
(evidence / "comparison.json").write_text(json.dumps({"schema_version": 1, "paragraphs": comparison}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8-sig")
print(json.dumps(result, ensure_ascii=True, indent=2))
