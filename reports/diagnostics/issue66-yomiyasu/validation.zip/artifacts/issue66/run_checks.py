﻿"""Issue #66 の限定検証結果と、検証対象の指紋を保存する。"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

root = Path.cwd()
phase = sys.argv[1]
if phase not in ("before", "after", "final", "publication", "publication-final"):
    raise SystemExit("検証段階は before / after / final / publication です。")
evidence = root / "artifacts/issue66"
out = evidence / phase
out.mkdir(parents=True, exist_ok=False)
selection = json.loads((root / "reports/diagnostics/issue66-yomiyasu/selection.json").read_text(encoding="utf-8-sig"))
documents = selection["documents"]
files = [d["path"] for d in documents]
if phase in ("publication", "publication-final"):
    files.extend(["Tracker/Design/tasks-status.md", "Tracker/Design/phases-status.md"])
configs = ["package.json", "package-lock.json", ".textlintrc.json", ".textlintignore", "cspell.config.jsonc", "tools/lint/markdown-targets.json", "tools/lint/markdown-whitelist.yaml", "tools/lint/prh.yml", "tools/lint/requirements.txt"]
scripts = root / ".agents/skills/review-enforcer/scripts"
yomi = root / "artifacts/issue66/yomiyasu/skills/yomiyasu"

def digest(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def git(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=root).decode("utf-8").strip()

manifest = {p: digest(root / p) for p in files + configs}
for directory in (scripts, yomi):
    for p in sorted(directory.rglob("*")):
        if p.is_file() and p.suffix in (".js", ".py", ".md", ".txt"):
            manifest[p.relative_to(root).as_posix()] = digest(p)
fingerprint = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode("utf-8")).hexdigest()
state = {"phase": phase, "started_at": datetime.now(timezone.utc).isoformat(), "cwd": str(root), "branch": git("branch", "--show-current"), "head": git("rev-parse", "HEAD"), "git_status": git("status", "--short"), "source_fingerprint": fingerprint, "files_sha256": manifest, "commands": []}
(out / "source.json").write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8-sig")
env = dict(os.environ)
env["PYTHONUTF8"] = "1"
env["PYTHONIOENCODING"] = "utf-8"

def run(name: str, args: list[str]) -> int:
    stdout = out / (name + ".stdout.log")
    stderr = out / (name + ".stderr.log")
    started = datetime.now(timezone.utc).isoformat()
    with stdout.open("wb") as o, stderr.open("wb") as e:
        result = subprocess.run(args, cwd=root, env=env, stdout=o, stderr=e, check=False)
    row = {"name": name, "argv": args, "started_at": started, "finished_at": datetime.now(timezone.utc).isoformat(), "exit_code": result.returncode, "stdout": stdout.relative_to(root).as_posix(), "stderr": stderr.relative_to(root).as_posix(), "head": state["head"], "source_fingerprint": fingerprint}
    state["commands"].append(row)
    (out / "results.json").write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8-sig")
    print(json.dumps({"name": name, "exit_code": result.returncode}, ensure_ascii=True), flush=True)
    return result.returncode

codes = []
codes.append(run("textlint", ["node", "node_modules/textlint/bin/textlint.js", "--config", ".textlintrc.json", "--rulesdir", str(scripts / "textlint-rules"), "--format", "json", *files]))
codes.append(run("cspell", ["node", str(scripts / "run-cspell-markdown.js"), *files]))
codes.append(run("whitelist", [str(root / ".venv/Scripts/python.exe"), str(scripts / "check-markdown-whitelist-sudachi.py"), "--files", *files]))

if phase in ("before", "after", "final"):
    for doc in documents:
        current = (root / doc["path"]).read_text(encoding="utf-8-sig").splitlines()
        paragraphs = [current[p["original_line"] - 1] for p in doc["paragraphs"]]
        if phase == "before":
            assert digest(root / doc["path"]) == doc["original_sha256"]
            assert paragraphs == [p["original_text"] for p in doc["paragraphs"]]
        sample = out / (doc["key"] + ".md")
        sample.write_text("\n\n".join(paragraphs) + "\n", encoding="utf-8-sig")
        codes.append(run("yomiyasu-lint-" + doc["key"], [sys.executable, str(yomi / "scripts/yomiyasu_lint.py"), str(sample), "--json"]))
        if phase in ("after", "final"):
            original = evidence / "before" / sample.name
            codes.append(run("yomiyasu-diff-" + doc["key"], [sys.executable, str(yomi / "scripts/yomiyasu_diff.py"), str(original), str(sample), "--stance=説明", "--json"]))

codes.append(run("git-diff-check", ["git", "diff", "--check"]))
raise SystemExit(0 if all(code == 0 for code in codes) else 1)
