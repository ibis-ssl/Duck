﻿"""Execute the repository product gate with captured diagnostics."""
from pathlib import Path
import os,sys,json,hashlib,subprocess
from datetime import datetime,timezone
ROOT=Path('C:/Users/donabe/RemoteDesktopWorkspace/Duck-issue66-yomiyasu')
E=ROOT.parent/'Duck-issue66-prose-evidence-20261008'
O=E/'product-gate';O.mkdir(exist_ok=False)
D=Path('C:/Program Files/dotnet/dotnet.exe')
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT).decode().strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest={p:sha(ROOT/p) for p in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0') if p and (ROOT/p).is_file()}
state={'head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'cwd':str(ROOT),'git_status':git('status','--short'),'started_at':datetime.now(timezone.utc).isoformat(),'files_sha256':manifest,'source_fingerprint':hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest(),'commands':[]}
assert state['head']=='506c5342f646e0392532ff02f429196254e8f670'
env=dict(os.environ);env['PATH']=str(D.parent)+os.pathsep+env.get('PATH','');env['DOTNET_CLI_HOME']=str(O/'dotnet-home');env['DOTNET_CLI_TELEMETRY_OPTOUT']='1';env['DOTNET_SKIP_FIRST_TIME_EXPERIENCE']='1'
state['task_environment_overrides']={k:env[k] for k in ['DOTNET_CLI_HOME','DOTNET_CLI_TELEMETRY_OPTOUT','DOTNET_SKIP_FIRST_TIME_EXPERIENCE']};state['task_path_prefix']=str(D.parent)
def run(name,args):
 row={'name':name,'argv':list(map(str,args)),'cwd':str(ROOT),'head':state['head'],'source_fingerprint':state['source_fingerprint'],'started_at':datetime.now(timezone.utc).isoformat(),'stdout':str(O/(name+'.stdout.log')),'stderr':str(O/(name+'.stderr.log'))}
 with open(row['stdout'],'wb') as out,open(row['stderr'],'wb') as err:r=subprocess.run(row['argv'],cwd=ROOT,env=env,stdout=out,stderr=err)
 row.update(exit_code=r.returncode,result='passed' if r.returncode==0 else 'failed',finished_at=datetime.now(timezone.utc).isoformat());state['commands'].append(row)
 (O/'results.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8-sig');print(json.dumps({k:row[k] for k in ['name','result','exit_code']}),flush=True)
 return r.returncode
run('dotnet-info',[D,'--info'])
code=run('dotnet-test',[D,'test','Tracker/Tracker.Tests/Tracker.Tests.csproj','--logger','trx;LogFileName=dotnet-test.trx','--results-directory',O,'--diag',O/'vstest-diagnostics.log','--blame','-m:1','/nr:false','-bl:'+str(O/'dotnet-test.binlog')])
(O/'dotnet-test.exit-code').write_text(str(code)+'\n')
state['source_unchanged_during_validation']=all(sha(ROOT/p)==v for p,v in manifest.items());state['finished_at']=datetime.now(timezone.utc).isoformat()
state['diagnostics']=[{'path':str(p),'sha256':sha(p),'size':p.stat().st_size} for p in O.rglob('*') if p.is_file() and 'dotnet-home' not in p.parts and p.name!='results.json']
(O/'results.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8-sig')
assert state['source_unchanged_during_validation'];sys.exit(code)
