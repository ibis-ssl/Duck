﻿"""Duckの文章改善に対する既存検査を実行し、原本と結果を結び付ける。"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path('C:/Users/donabe/RemoteDesktopWorkspace/Duck-issue66-yomiyasu')
EVIDENCE = Path('C:/Users/donabe/RemoteDesktopWorkspace/Duck-issue66-prose-evidence-20261008')
NODE = Path('C:/Program Files/nodejs/node.exe')
DOTNET = Path('C:/Program Files/dotnet/dotnet.exe')
LINT_PYTHON = ROOT / '.venv/Scripts/python.exe'
SCRIPTS = ROOT / '.agents/skills/review-enforcer/scripts'
YOMI = ROOT / 'artifacts/issue66/yomiyasu/skills/yomiyasu'
phase = sys.argv[1]
assert phase in {'before', 'candidate', 'final', 'publication'}
out = EVIDENCE / phase
out.mkdir(exist_ok=False)
env = dict(os.environ)
env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8')

def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=ROOT).decode('utf-8').strip()

def digest(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

meta = json.loads((EVIDENCE / 'source-manifest.json').read_text(encoding='utf-8-sig'))
manifest = {f['path']: digest(ROOT / f['path']) for f in meta['files']}
for prefix, folder in [('shared_scripts', SCRIPTS), ('yomiyasu', YOMI)]:
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix in {'.js', '.py', '.md', '.txt'}:
            manifest[prefix + '/' + p.relative_to(folder).as_posix()] = digest(p)
fingerprint = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode('utf-8')).hexdigest()
state = {
    'phase': phase, 'started_at': datetime.now(timezone.utc).isoformat(),
    'cwd': str(ROOT), 'head': git('rev-parse', 'HEAD'),
    'branch': git('branch', '--show-current'), 'git_status': git('status', '--short'),
    'source_fingerprint': fingerprint, 'files_sha256': manifest,
    'python': sys.version, 'python_executable': sys.executable,
    'shared_skill_head': git('-C', str(SCRIPTS.resolve().parents[2]), 'rev-parse', 'HEAD'),
    'yomiyasu_head': git('-C', str(YOMI.parents[1]), 'rev-parse', 'HEAD'),
    'commands': [],
}
assert state['branch'] == 'docs/issue66-yomiyasu-pilot'
assert state['yomiyasu_head'] == '0df47749139dfd64ad3d55e7d53d3839e5874848'
if phase == 'before':
    assert state['head'] == meta['head'] and not state['git_status']
    assert all(manifest[f['path']] == f['sha256'] for f in meta['files'])

def save() -> None:
    (out / 'results.json').write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n', encoding='utf-8-sig')

def run(name: str, argv: list[str | Path], required: bool = True) -> subprocess.CompletedProcess | None:
    args = [str(a) for a in argv]
    row = {'name': name, 'argv': args, 'cwd': str(ROOT), 'started_at': datetime.now(timezone.utc).isoformat(),
           'head': state['head'], 'source_fingerprint': fingerprint, 'required': required,
           'stdout': str(out / (name + '.stdout.log')), 'stderr': str(out / (name + '.stderr.log'))}
    try:
        result = subprocess.run(args, cwd=ROOT, env=env, capture_output=True, check=False)
        Path(row['stdout']).write_bytes(result.stdout)
        Path(row['stderr']).write_bytes(result.stderr)
        row.update(exit_code=result.returncode, result='passed' if result.returncode == 0 else 'failed')
    except OSError as ex:
        Path(row['stdout']).write_bytes(b'')
        Path(row['stderr']).write_text(repr(ex), encoding='utf-8-sig')
        row.update(exit_code=None, result='not_run', error=repr(ex))
        result = None
    row['finished_at'] = datetime.now(timezone.utc).isoformat()
    state['commands'].append(row)
    save()
    print(json.dumps({'name': name, 'exit_code': row['exit_code'], 'result': row['result']}, ensure_ascii=False), flush=True)
    return result

save()
run('node-version', [NODE, '--version'])
run('lint-python-version', [LINT_PYTHON, '-c', 'import sys,sudachipy,yaml; print(sys.version); print(sudachipy.__version__); print(yaml.__version__)'])
listed = run('full-targets', [NODE, SCRIPTS / 'list-markdown-targets.js', '--print0'])
if listed is None or listed.returncode:
    raise SystemExit(1)
files = [p for p in listed.stdout.decode('utf-8').split('\0') if p]
state['full_targets'] = files
save()
run('textlint-full', [NODE, ROOT / 'node_modules/textlint/bin/textlint.js', '--config', ROOT / '.textlintrc.json', '--rulesdir', SCRIPTS / 'textlint-rules', '--format', 'json', *files])
run('cspell-full', [NODE, SCRIPTS / 'run-cspell-markdown.js', *files])
run('whitelist-full', [LINT_PYTHON, SCRIPTS / 'check-markdown-whitelist-sudachi.py'])

if phase in {'before', 'candidate', 'final'}:
    for index, f in enumerate(files):
        run(f'yomiyasu-lint-{index:02}', [sys.executable, YOMI / 'scripts/yomiyasu_lint.py', ROOT / f, '--json'], required=False)
        if phase in {'candidate', 'final'}:
            original = EVIDENCE / 'original' / f
            assert original.is_file(), original
            if digest(original) != digest(ROOT / f):
                run(f'yomiyasu-diff-{index:02}', [sys.executable, YOMI / 'scripts/yomiyasu_diff.py', original, ROOT / f, '--stance=説明', '--json'], required=False)

run('git-diff-check', ['git', 'diff', '--check'])
state['finished_at'] = datetime.now(timezone.utc).isoformat()
state['source_unchanged_during_validation'] = all(digest(ROOT / f['path']) == manifest[f['path']] for f in meta['files'])
save()
assert state['source_unchanged_during_validation']
raise SystemExit(0 if all(r['result'] == 'passed' for r in state['commands'] if r['required']) else 1)
