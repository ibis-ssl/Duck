﻿"""Persist the Duck prose report, diagnostics and complete handoff on the connected PC."""
from pathlib import Path
import hashlib,json,subprocess,zipfile,shutil,re,sys,importlib.util
import xml.etree.ElementTree as ET
from datetime import datetime,timezone
ROOT=Path('C:/Users/donabe/RemoteDesktopWorkspace/Duck-issue66-yomiyasu')
E=ROOT.parent/'Duck-issue66-prose-evidence-20261008'
INPUT=E/'delivery-input'
with zipfile.ZipFile(E/'delivery-input.zip') as z:
 for n in z.namelist():assert not Path(n).is_absolute() and '..' not in Path(n).parts
 if INPUT.exists():
  assert all((INPUT/n).read_bytes()==z.read(n) for n in z.namelist())
 else:z.extractall(INPUT)
spec=importlib.util.spec_from_file_location('populate_handoff',INPUT/'populate_handoff.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').replace('\n','\r\n').encode('utf-8-sig'))
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT).decode('utf-8').strip()
HEAD='506c5342f646e0392532ff02f429196254e8f670';OLD='c9c44913d443410ae4768b26faafd48fa367b2e2'
assert git('rev-parse','HEAD')==HEAD and git('branch','--show-current')=='docs/issue66-yomiyasu-pilot'
phases=['before','baseline-clean','candidate-clean','final-clean','final-fixed','product-gate','product-gate-retry','product-baseline-retry','product-baseline-final']
results={n:read(E/n/'results.json') for n in phases}
final=results['final-fixed'];after=results['product-gate-retry'];before=results['product-baseline-final']
assert final['source_unchanged_during_validation'] and all(x['result']=='passed' for x in final['commands'] if x['required'])
assert before['head']==OLD and after['head']==HEAD and before['source_unchanged_during_validation'] and after['source_unchanged_during_validation']
assert all(sha(ROOT/f)==v for f,v in final['source_files_sha256'].items())
def testdata(n):
 t=ET.parse(E/n/'dotnet-test.trx');counts=t.find('.//{*}Counters').attrib
 failed=[{'name':x.attrib['testName'],'message':x.find('.//{*}Message').text,'stack':x.find('.//{*}StackTrace').text} for x in t.findall('.//{*}UnitTestResult') if x.attrib.get('outcome')=='Failed']
 return {'counts':counts,'failures':failed}
a=testdata('product-gate-retry');b=testdata('product-baseline-final')
same={x['name'] for x in a['failures']}=={x['name'] for x in b['failures']}
nonmd=[f for f in git('diff','--name-only',OLD,'HEAD').splitlines() if not f.endswith('.md')]
assert not nonmd
comparison={'before_head':OLD,'after_head':HEAD,'before_fingerprint':before['source_fingerprint'],'after_fingerprint':after['source_fingerprint'],'before':b,'after':a,'failed_test_names_equal':same,'non_markdown_changes_between_commits':nonmd,'same_file_sharing_error_family':all('System.IO.IOException' in x['message'] and 'being used by another process' in x['message'] for x in a['failures']+b['failures'])}
assert same and comparison['same_file_sharing_error_family'] and a['counts']==b['counts'],comparison
write(E/'baseline-comparison.json',comparison)
D=ROOT/'reports/diagnostics/issue66-non-report-prose-20261008';R=ROOT/'reports/issue66-non-report-prose-20261008.md';H=ROOT/'handoffs/issue66-non-report-prose-20261008.json'
assert not D.exists() and not R.exists() and not H.exists();D.mkdir(parents=True)
# Preserve original records byte-for-byte, including failures and intermediate decisions.
for p in (E/'proposal-package').glob('*.json'):shutil.copy2(p,D/p.name)
for n in ['source-manifest.json','original-source.zip','apply-results.json','technical-commit.json','submodule-init.json','submodules-before.log','submodules-after.log','submodule-init.stdout.log','submodule-init.stderr.log','yomiyasu-summary.json','product-failures.json','baseline-comparison.json']:
 shutil.copy2(E/n,D/n)
for n in phases:
 (D/n).mkdir();shutil.copy2(E/n/'results.json',D/n/'results.json')
with zipfile.ZipFile(D/'validation-logs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in phases:
  for p in (E/n).rglob('*'):
   rel=p.relative_to(E/n)
   if not p.is_file() or any(x in rel.parts for x in ['source','dotnet-home']):continue
   if p.name=='results.json':continue
   z.write(p,n+'/'+rel.as_posix())
 for p in E.glob('*.py'):z.write(p,'helpers/'+p.name)
 for n in ['submodule-init.json','submodule-init.stdout.log','submodule-init.stderr.log','submodules-before.log','submodules-after.log']:z.write(E/n,'initialization/'+n)
# Record operational errors separately from repository test failures.
ops={'preparation_events':[{'operation':'baseline product second attempt','result':'failed','exit_code':1,'reason':'MSB3030: the baseline-specific NuGet cache lacked Microsoft.Extensions.Configuration.EnvironmentVariables.dll. No unit tests ran. The final attempt used the actual complete package cache observed in the tested worktree project.assets.json; no package version or configuration was changed.'},{'operation':'dependency discovery via dotnet on PATH','result':'not_run','reason':'dotnet was not on PATH; explicit C:/Program Files/dotnet/dotnet.exe used subsequently.'},{'operation':'baseline product setup','result':'failed','exit_code':128,'reason':'Git status followed reused submodule junctions and resolved relative Git metadata under the wrong worktree. Parent-source status and dependency-source status were then read at their actual locations. No product test was executed in that failed preparation.'},{'operation':'RDMCP helper upload','result':'failed','reason':'Internal tool error. Read-only verification showed the file absent; retry saved the same verified payload.'},{'operation':'Todo freshness guarded reads','result':'blocked','reason':'Stale Todo prevented a read/summary operation. Progress was refreshed before retry; no source mutation occurred in the rejected operations.'},{'operation':'scratch helper preparation','result':'failed_then_corrected','reason':'BOM decoding, helper staging imports and syntax, and a diagnostic filename selection were corrected before the corresponding publication helper was used.'}],'repository_validation_failures_preserved':[n for n in phases if any(x['result']!='passed' for x in results[n]['commands'] if x.get('required',True))]}
write(D/'operational-diagnostics.json',ops)
body=(INPUT/'report-final-ready.md').read_text(encoding='utf-8-sig')
text=f"変更前コミット `{OLD}` を独立した比較領域で検証したところ、{b['counts']['total']} 件中 {b['counts']['passed']} 件成功、{b['counts']['failed']} 件失敗、スキップ {b['counts']['notExecuted']} 件だった。変更後と失敗したテスト名が全件一致し、いずれも開いている補助ファイルを読み取る際の `System.IO.IOException` だった。2つのコミット間で製品コード・テスト・設定は変わっていない。今回の文章変更以前から同じ Windows のファイル共有エラーが再現することを確認した。この失敗は成功へ読み替えず、製品コードの修正は今回の文章改善へ混ぜていない。比較の全文は [baseline-comparison.json](diagnostics/issue66-non-report-prose-20261008/baseline-comparison.json)、変更前の実行記録は [product-baseline-final/results.json](diagnostics/issue66-non-report-prose-20261008/product-baseline-final/results.json) を参照する。"
assert body.count('{BASELINE_COMPARISON_TEXT}')==1
body=body.replace('{BASELINE_COMPARISON_TEXT}',text).replace('product-baseline/','product-baseline-final/')
body=body.replace('残る作業は、変更前の製品テストとの比較結果を反映すること、最終的な文書・報告・診断記録を保存して管理用コミットを作成すること、push 後に PR の対象 HEAD と CI の結果を対応付けることである。','変更前の製品テストとの比較結果を反映し、報告と診断記録を保存した。残る作業は管理用コミットを作成すること、push 後に PR の対象 HEAD と CI の結果を対応付けることである。')
body=body.replace('同じテストを別の worktree で実行し、今回の 11 件と比較する。','同じテストを別の worktree で実行し、今回の 11 件と比較した。')
body=body.replace('| 最終的な文書・報告・診断記録の保存と管理用コミット | 未完了。 |','| 最終的な文書・報告・診断記録の保存と管理用コミット | 本書・診断・引継ぎを保存。管理用コミットは本書保存後に作成する。 |')
body=body.replace('初期化のコマンドと出力は','初期化の終了状態と出力は')
body=body.replace('報告書と診断記録を含む最終的な文書の保存と管理用コミット、push、公開後の対象 HEAD に対する CI 確認は未完了である。','本書と診断記録を保存した時点では、管理用コミット、push、公開後の対象 HEAD に対する CI 確認は未完了である。')
body+='\n## 実行場所と公開時の照合\n\n実行は接続PCの専用作業領域で行った。本文の全文検査は、追跡対象の全ファイルをバイト一致で複製した領域を作業ディレクトリにした。依存と検査設定は各結果JSONに記録している。変更前比較では専用worktreeでビルドし、固定コミットで内容が変わっていない依存ソースを参照した。基準比較の準備時エラーは operational-diagnostics.json に区別して記録した。\n\n最終公開前に、文書検査が実際に読んだ全ファイルのハッシュと公開する本文を照合する。報告、診断、引継ぎの追加は製品コードを変えず、既存の文書検査設定が定める18文書も変えない。新しい報告書の参照先、JSON形式、差分の空白は別途検査する。ローカル製品テストは前後で同じ11件が失敗しており、ローカル検証全体を成功とは記録しない。最終HEADに対応するLinuxのCI結果は、公開後のPRコメントに記録する。\n'
R.write_bytes(body.replace('\n','\r\n').encode('utf-8-sig'))
commands=[];tests=[];failures=[]
for phase,data in results.items():
 for row in data['commands']:
  env={'kind':'connected_computer','tool':'RemoteDesktopMCP','machine_id':'local','connection':'available','os':'Windows','shell':'cmd.exe; explicit subprocess argv','working_directory':row['cwd'],'repository':'ibis-ssl/Duck','branch':data.get('branch') or 'detached','head_sha':row.get('head',data['head']),'source_state':'clean' if phase in ['before','baseline-clean','product-baseline-retry','product-baseline-final'] else 'dirty','source_fingerprint':row.get('source_fingerprint',data['source_fingerprint']),'ownership':'current_task'}
  evidence='reports/diagnostics/issue66-non-report-prose-20261008/'+phase+'/results.json'
  commands.append({'command':subprocess.list2cmdline(row['argv']),'purpose':phase+': '+row['name'],'exit_code':row['exit_code'] if row['exit_code'] is not None else 'unknown','result':row['result'],'head_sha':env['head_sha'],'evidence':evidence,'execution_environment':env,'source_fingerprint':env['source_fingerprint'],'argv':row['argv'],'stdout':row['stdout'],'stderr':row['stderr'],'required':row.get('required',True)})
  tests.append({'name':phase+': '+row['name'],'phase':'pre_implementation' if phase in ['before','baseline-clean','product-baseline-retry','product-baseline-final'] else 'verification','result':row['result'],'head_sha':env['head_sha'],'evidence':evidence})
  if row['result']!='passed':failures.append({'type':'log','location':evidence,'summary':phase+': '+row['name']+'; stdout/stderr and detailed diagnostic files preserved in validation-logs.zip.'})
selected=read(D/'selected-proposals.json')
changed=[{'path':x['path'],'purpose':'意味と条件を保持した説明文の改善'} for x in read(E/'apply-results.json')['files']]
changed += [{'path':R.relative_to(ROOT).as_posix(),'purpose':'実装と成功・失敗の検証結果の報告'},{'path':H.relative_to(ROOT).as_posix(),'purpose':'schema 3 の完全な引継ぎ'},{'path':D.relative_to(ROOT).as_posix()+'/','purpose':'原文・採否・検証と失敗診断の保全'}]
env={'kind':'connected_computer','tool':'RemoteDesktopMCP','machine_id':'local','connection':'available','os':'Windows','shell':'cmd.exe','working_directory':str(ROOT),'repository':'ibis-ssl/Duck','branch':'docs/issue66-yomiyasu-pilot','head_sha':HEAD,'source_state':'dirty','source_fingerprint':final['source_fingerprint'],'ownership':'current_task','writable_paths':[str(ROOT),str(E)],'dependencies':[{'name':'Node.js / textlint / CSpell / SudachiPy / PyYAML','status':'available','evidence':'baseline-clean, candidate-clean and final-fixed results.json'},{'name':'.NET SDK 10.0.401','status':'available','evidence':'product-gate-retry/results.json and dotnet-info stdout'},{'name':'pinned SSL protocol submodules','status':'available','evidence':'submodule-init.json and product-gate-retry/results.json'},{'name':'pinned yomiyasu v1.1.0','status':'available','evidence':'0df47749139dfd64ad3d55e7d53d3839e5874848; final-fixed/results.json'}],'evidence':['source-manifest.json','final-fixed/results.json','product-gate-retry/results.json','baseline-comparison.json']}
context={'generated_at':datetime.now(timezone.utc).isoformat(),'technical_head':HEAD,'original_head':OLD,'source_fingerprint':final['source_fingerprint'],'execution_environment':env,'commands':commands,'tests':tests,'validation_results':results,'comparison':comparison,'failure_diagnostics':failures,'changed_files':changed,'artifact_paths':[R.relative_to(ROOT).as_posix(),H.relative_to(ROOT).as_posix(),D.relative_to(ROOT).as_posix()+'/validation-logs.zip']}
# The context adapter is checked against populate_handoff's declared contract before use.
context['control_session_working_directory']=str(ROOT.parent)
context['ci_workflow']='.github/workflows/dotnet-test.yml'
context['submodule_initialization']=read(E/'submodule-init.json')
init=context['submodule_initialization'];init_env=dict(env,working_directory=init['cwd'],head_sha=init['head'],source_state='unknown',source_fingerprint='unknown')
commands.append({'command':'unknown (fixed gitlink submodule initialization; exact argv was not retained in submodule-init.json)','purpose':'Initialize the two existing pinned SSL protocol dependencies before product-gate-retry','exit_code':init['exit_code'],'result':'passed' if init['exit_code']==0 else 'failed','head_sha':init['head'],'evidence':'reports/diagnostics/issue66-non-report-prose-20261008/submodule-init.json','execution_environment':init_env,'source_fingerprint':'unknown'})
context['unknown']=[{'field_or_fact':'Exact initialization argv and source fingerprint at that operation','reason':'The original submodule-init.json retains HEAD/cwd/exit code and before/after pinned states, but not argv or a source fingerprint. These values are not reconstructed.'}]
for row in commands:
 ce=row['execution_environment'];ce.setdefault('writable_paths',[ce['working_directory'],str(E)]);ce.setdefault('dependencies',[]);ce.setdefault('evidence',[row['evidence']])
context['validation_summary']={'documentation':[{'name':n,'result':'passed','evidence':'reports/diagnostics/issue66-non-report-prose-20261008/final-fixed/results.json'} for n in ['textlint','CSpell','Sudachi whitelist']],'product':{'total':int(a['counts']['total']),'passed':int(a['counts']['passed']),'failed':int(a['counts']['failed']),'failure_description':'Windows file sharing System.IO.IOException in eleven tests, with preserved TRX and logs'},'baseline_statement':text}
packet=mod.build_handoff(read(INPUT/'handoff-template.json'),body,context)
write(H,packet)
# Validate every ordinary relative Markdown file link in the report.
links=[]
for target in re.findall(r'(?<!!)\[[^\]\n]+\]\(([^)\s]+)\)',body):
 if re.match(r'^[a-z]+:',target) or target.startswith('#'):continue
 target=target.split('#',1)[0];p=(R.parent/target).resolve();assert p.exists(),str(p);links.append(target)
assert packet['schema_version']==3 and len(packet['source_payloads'])>=3 and all(x['payload'] for x in packet['source_payloads'])
assert not re.search(r'\{\{[^}]+\}\}|\{BASELINE_COMPARISON_TEXT\}',body)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
index={'generated_at':datetime.now(timezone.utc).isoformat(),'validated_source_fingerprint':final['source_fingerprint'],'source_unchanged_before_publication':all(sha(ROOT/f)==v for f,v in final['source_files_sha256'].items()),'report_relative_links_checked':len(links),'files':[{'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p),'size':p.stat().st_size} for p in sorted(D.rglob('*')) if p.is_file()]}
write(E/'delivery-result.json',{'report':str(R),'handoff':str(H),'diagnostics':str(D),'index':index,'comparison_counts':a['counts'],'same_failed_tests':same})
write(D/'evidence-index.json',index)
print(json.dumps({'report':str(R),'handoff':str(H),'diagnostic_files':len(index['files'])+1,'report_links':len(links),'same_failed_tests':same,'log_archive_bytes':(D/'validation-logs.zip').stat().st_size},ensure_ascii=False),flush=True)
