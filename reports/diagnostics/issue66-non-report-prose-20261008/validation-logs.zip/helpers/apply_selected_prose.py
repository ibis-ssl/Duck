﻿"""Guard all input hashes before writing the accepted Duck prose changes."""
import json,hashlib,subprocess,zipfile,re
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
ROOT=Path('C:/Users/donabe/RemoteDesktopWorkspace/Duck-issue66-yomiyasu')
E=ROOT.parent/'Duck-issue66-prose-evidence-20261008'
P=E/'proposal-package'
assert not P.exists()
with zipfile.ZipFile(E/'proposal-package.zip') as z:
    for n in z.namelist():assert not Path(n).is_absolute() and '..' not in Path(n).parts
    z.extractall(P)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT).decode('utf-8').strip()
def sha(b):return hashlib.sha256(b).hexdigest()
meta=json.loads((E/'source-manifest.json').read_text(encoding='utf-8-sig'))
selected=json.loads((P/'selected-proposals.json').read_text(encoding='utf-8-sig'))
progress=json.loads((P/'progress-addition-proposals.json').read_text(encoding='utf-8-sig'))
assert git('rev-parse','HEAD')==meta['head']==selected['source_head']
assert git('branch','--show-current')=='docs/issue66-yomiyasu-pilot' and not git('status','--porcelain')
baseline=json.loads((E/'baseline-clean/results.json').read_text(encoding='utf-8-sig'))
assert baseline.get('source_unchanged_during_validation') and all(x['result']=='passed' for x in baseline['commands'] if x['required'])
for f in meta['files']:assert sha((ROOT/f['path']).read_bytes())==f['sha256'],f['path']
assert len(selected['proposals'])==84
texts={f['path']:(ROOT/f['path']).read_text(encoding='utf-8-sig') for f in meta['files'] if f['path'].endswith('.md')}
# Register the newly authorized scope before the prose changes.
for r in progress['proposals']:
    a=r['original_text'].replace('\r\n','\n');b=r['replacement_text'].replace('\r\n','\n')
    assert texts[r['path']].count(a)==1,r['id']
    texts[r['path']]=texts[r['path']].replace(a,b,1)
for r in selected['proposals']:
    a=r['original_text'].replace('\r\n','\n');b=r['replacement_text'].replace('\r\n','\n')
    assert texts[r['path']].count(a)==1,r['id']
    texts[r['path']]=texts[r['path']].replace(a,b,1)
state={'head_before':meta['head'],'started_at':datetime.now(timezone.utc).isoformat(),'accepted_changes':84,'progress_changes':2,'files':[],'root_decision':selected['root_approval']}
changes={r['path'] for r in selected['proposals']}|{r['path'] for r in progress['proposals']}
for f in sorted(changes):
    raw=(ROOT/f).read_bytes();body=raw.decode('utf-8-sig')
    eol='\r\n' if '\r\n' in body else '\n'
    assert eol!='\r\n' or '\n' not in body.replace('\r\n',''),f
    new=texts[f].replace('\n',eol).encode('utf-8-sig')
    state['files'].append({'path':f,'before_sha256':sha(raw),'after_sha256':sha(new),'newline':'CRLF' if eol=='\r\n' else 'LF','utf8_bom':True})
    # All matches and hashes above have passed before any source file is changed.
    (ROOT/f).write_bytes(new)
    c=E/'candidate-applied'/f;c.parent.mkdir(parents=True,exist_ok=True);c.write_bytes(new)
state['git_status']=git('status','--short');state['finished_at']=datetime.now(timezone.utc).isoformat()
(E/'apply-results.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8-sig')
print(json.dumps({'changed_documents':len(changes),'prose_changes':84,'progress_updates':2,'git_status':state['git_status']},ensure_ascii=False),flush=True)
