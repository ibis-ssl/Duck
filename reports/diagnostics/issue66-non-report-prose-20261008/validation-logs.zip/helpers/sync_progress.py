﻿"""Synchronize the current progress entry before the final local gates."""
from pathlib import Path
import json,subprocess,hashlib
ROOT=Path('C:/Users/donabe/RemoteDesktopWorkspace/Duck-issue66-yomiyasu')
E=ROOT.parent/'Duck-issue66-prose-evidence-20261008'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()
assert head=='506c5342f646e0392532ff02f429196254e8f670'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT).strip()
report='reports/issue66-non-report-prose-20261008.md'
diag='reports/diagnostics/issue66-non-report-prose-20261008/'
p=ROOT/'Tracker/Design/tasks-status.md';t=p.read_text(encoding='utf-8-sig')
a=t.index('- ID: `DOC-PROSE-002`');b=t.index('- ID: `DOC-PROSE-001`',a)
new="""- ID: `DOC-PROSE-002`
- 題名: レポート以外の説明文を追加で推敲する
- 段階: 文書の推敲と評価
- 状態: 19文書を確認し、15文書84箇所の推敲と原文の照合を完了した。4文書は原文を維持した。
- 規模: 中
- 依存関係: `DOC-PROSE-001` の試行結果と、Duck 内のレポート以外の文章も扱う利用者の追加依頼を基準にする。課題 #31、#64、PR #65 の作業は別範囲として扱う。
- 対象: Duck 内のレポート以外の19文書。初回の2文書・8段落とは分けて記録する。84箇所は文、段落、表の記述などの変更単位を数えたもの。
- 完了条件:
  - 原文の意味、条件、否定、数値、名称、識別子、コマンド、ソースコード、URLを保持し、説明文の読みやすさを改善する。
  - 変更した文書の全文と、既存設定が定める全対象に文書検査3種を実行し、結果を記録する。許可一覧と検査の除外設定は変更しない。
  - 変更した箇所と原文を維持した箇所の判断を、追加対応分の記録に残す。
- 検証: 変更前後とも、追跡対象の内容を変えずに複製した検証領域で、既存設定が定める18文書の文書検査3種が成功した。コード、数値、脚注、リンク先の保持も照合した。最終公開時の結果は報告書とPRコメントで確定する。
- 証跡: `REPORT` と `DIAG`。
- 公開先: 下書き [PR #67](https://github.com/ibis-ssl/Duck/pull/67)。追加推敲の実装コミットは `506c5342f646e0392532ff02f429196254e8f670`。
- 残りの作業: この記録を含む最終内容の検証と公開を終え、公開後のPRの最新コミットに対応するCIを確認してPRコメントへ記録する。独立レビューと人による受入は未完了であり、統合は利用者が行う。


"""
new=new.replace('REPORT',report).replace('DIAG',diag)
p.write_bytes((t[:a]+new+t[b:]).replace('\n','\r\n').encode('utf-8-sig'))
p=ROOT/'Tracker/Design/phases-status.md';t=p.read_text(encoding='utf-8-sig')
t=t.replace('- 現在の段階: 課題 #66 の初回試行に続き、利用者の追加依頼による Duck 内の説明文の推敲を進めている。','- 現在の段階: 課題 #66 の初回試行に続き、利用者の追加依頼による Duck 内の説明文の推敲を実装した。')
t=t.replace('- 追加対象: レポート以外の19文書。初回の選定8段落とは分けて記録する。','- 追加対象: レポート以外の19文書を確認し、15文書84箇所を修正した。4文書は原文を維持した。初回の選定8段落とは分けて記録する。')
t=t.replace('- 追加分の状態: 文書の推敲と検証の途中。追加分のコミット、PRへの反映、CI確認は未完了。','- 追加分の状態: 推敲と原文の照合を完了し、既存設定が定める18文書の文書検査3種が成功した。最終公開時の検証とCI結果は報告書とPRコメントで確定する。')
t=t.replace('- 残りの作業: 追加分の推敲と検証を終え、結果を記録してコミットし、PRへ反映する。公開後のPRの最新コミットに対応するCIを確認する。独立レビューと人による受入は未完了であり、統合は利用者が行う。','- 残りの作業: この記録を含む最終内容の検証と公開を終え、公開後のPRの最新コミットに対応するCIを確認してPRコメントへ記録する。独立レビューと人による受入は未完了であり、統合は利用者が行う。')
t=t.replace('- 公開先: [PR #67](https://github.com/ibis-ssl/Duck/pull/67) は下書き。追加対応分は未反映。','- 公開先: 下書き [PR #67](https://github.com/ibis-ssl/Duck/pull/67)。追加推敲の実装コミットは `506c5342f646e0392532ff02f429196254e8f670`。')
t=t.replace('- 追加分の証跡: 報告書と検証記録の作成後に追記する。',f'- 追加分の証跡: `{report}` と `{diag}`。')
p.write_bytes(t.replace('\n','\r\n').encode('utf-8-sig'))
print(subprocess.check_output(['git','diff','--stat'],cwd=ROOT).decode())
