﻿"""Run the unmodified full Markdown gates on a tracked-source snapshot."""
from __future__ import annotations
import hashlib,json,os,shutil,subprocess,sys,zipfile
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path('C:/Users/donabe/RemoteDesktopWorkspace/Duck-issue66-yomiyasu')
EVIDENCE=ROOT.parent/'Duck-issue66-prose-evidence-20261008'
SCRIPTS=ROOT/'.agents/skills/review-enforcer/scripts'
YOMI=ROOT/'artifacts/issue66/yomiyasu/skills/yomiyasu'
NODE=Path('C:/Program Files/nodejs/node.exe')
LINT_PYTHON=ROOT/'.venv/Scripts/python.exe'
phase=sys.argv[1]
assert phase in {'baseline-clean','candidate-clean','final-clean','final-fixed'}
out=EVIDENCE/phase
out.mkdir(exist_ok=False)
source=out/'source'
source.mkdir()
meta=json.loads((EVIDENCE/'source-manifest.json').read_text(encoding='utf-8-sig'))
original=EVIDENCE/'original'
if not original.exists():
    with zipfile.ZipFile(EVIDENCE/'original-source.zip') as z:
        for n in z.namelist():
            assert not Path(n).is_absolute() and '..' not in Path(n).parts
        z.extractall(original)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT).decode('utf-8').strip()
assert git('branch','--show-current')=='docs/issue66-yomiyasu-pilot'
assert git('-C',str(YOMI.parents[1]),'rev-parse','HEAD')=='0df47749139dfd64ad3d55e7d53d3839e5874848'
if phase=='baseline-clean':
    assert git('rev-parse','HEAD')==meta['head'] and not git('status','--porcelain')
tracked=subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT).decode('utf-8').split('\0')
manifest={};omitted=[]
for entry in tracked:
    if not entry:continue
    modeobj,name=entry.split('\t',1);mode=modeobj.split()[0]
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    if mode=='160000':
        omitted.append({'path':name,'mode':mode,'reason':'git submodule entry, absent from parent tracked blobs'});continue
    assert mode in {'100644','100755'},(mode,name)
    src=ROOT/name;dst=source/name
    assert src.is_file(),name
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst);manifest[name]=sha(src)
    assert sha(dst)==manifest[name]
# Reuse the installed packages outside the source tree. The existing config ignores node_modules.
link=source/'node_modules'
junction=subprocess.run(['cmd','/d','/c','mklink','/J',str(link),str(ROOT/'node_modules')],capture_output=True)
(out/'dependency-junction.stdout.log').write_bytes(junction.stdout)
(out/'dependency-junction.stderr.log').write_bytes(junction.stderr)
assert junction.returncode==0
for f in meta['files']:
    assert sha(ROOT/f['path'])==sha(source/f['path'])
    if not f['path'].endswith('.md') or phase=='baseline-clean':assert sha(source/f['path'])==f['sha256']
state={'phase':phase,'started_at':datetime.now(timezone.utc).isoformat(),'head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'repository_cwd':str(ROOT),'validation_cwd':str(source),'git_status':git('status','--short'),'source_files_sha256':manifest,'omitted_gitlinks':omitted,'source_fingerprint':hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest(),'commands':[],'shared_skill_head':git('-C',str(SCRIPTS.resolve().parents[2]),'rev-parse','HEAD'),'yomiyasu_head':git('-C',str(YOMI.parents[1]),'rev-parse','HEAD'),'full_gate_method':'All tracked regular files copied byte-for-byte; unchanged full target config; dependencies outside source; node_modules junction ignored by existing config.'}
def save():(out/'results.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8-sig')
env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
def run(name,args,required=True,cwd=source):
    row={'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'head':state['head'],'source_fingerprint':state['source_fingerprint'],'started_at':datetime.now(timezone.utc).isoformat(),'required':required,'stdout':str(out/(name+'.stdout.log')),'stderr':str(out/(name+'.stderr.log'))}
    try:
        r=subprocess.run(row['argv'],cwd=cwd,env=env,capture_output=True)
        Path(row['stdout']).write_bytes(r.stdout);Path(row['stderr']).write_bytes(r.stderr)
        row.update(exit_code=r.returncode,result='passed' if not r.returncode else 'failed')
    except OSError as ex:
        r=None;row.update(exit_code=None,result='not_run',error=repr(ex))
        Path(row['stdout']).write_bytes(b'');Path(row['stderr']).write_text(repr(ex),encoding='utf-8-sig')
    row['finished_at']=datetime.now(timezone.utc).isoformat();state['commands'].append(row);save()
    print(json.dumps({k:row[k] for k in ['name','result','exit_code']},ensure_ascii=False),flush=True)
    return r
save()
listed=run('full-targets',[NODE,SCRIPTS/'list-markdown-targets.js','--print0'])
assert listed and listed.returncode==0
files=[x for x in listed.stdout.decode().split('\0') if x]
expected={f['path'] for f in meta['files'] if f['path'].endswith('.md') and f['path']!='feedback-points/feedback-points.md'}
assert set(files)==expected,(len(files),set(files)^expected)
state['full_targets']=files;save()
run('textlint-full',[NODE,source/'node_modules/textlint/bin/textlint.js','--config',source/'.textlintrc.json','--rulesdir',SCRIPTS/'textlint-rules','--format','json',*files])
run('cspell-full',[NODE,SCRIPTS/'run-cspell-markdown.js',*files])
run('whitelist-full',[LINT_PYTHON,SCRIPTS/'check-markdown-whitelist-sudachi.py'])
for i,f in enumerate(files):
    run(f'yomiyasu-lint-{i:02}',[sys.executable,YOMI/'scripts/yomiyasu_lint.py',source/f,'--json'],required=False)
    if phase!='baseline-clean' and sha(source/f)!=sha(original/f):
        run(f'yomiyasu-diff-{i:02}',[sys.executable,YOMI/'scripts/yomiyasu_diff.py',original/f,source/f,'--stance=説明','--json'],required=False)
run('git-diff-check',['git','diff','--check'],cwd=ROOT)
state['source_unchanged_during_validation']=all(sha(ROOT/f)==v and sha(source/f)==v for f,v in manifest.items())
state['finished_at']=datetime.now(timezone.utc).isoformat();save()
assert state['source_unchanged_during_validation']
sys.exit(0 if all(r['result']=='passed' for r in state['commands'] if r['required']) else 1)
