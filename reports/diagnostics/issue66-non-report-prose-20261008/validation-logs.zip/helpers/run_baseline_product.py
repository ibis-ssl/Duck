﻿"""Execute the repository product gate with captured diagnostics."""
from pathlib import Path
import os,sys,json,hashlib,subprocess
from datetime import datetime,timezone
ROOT=Path('C:/Users/donabe/RemoteDesktopWorkspace/Duck-issue66-yomiyasu')
E=ROOT.parent/'Duck-issue66-prose-evidence-20261008'
O=E/'product-baseline';O.mkdir(exist_ok=False)
ORIGINAL=ROOT
ROOT=E/'baseline-product-source'
assert not ROOT.exists()
subprocess.run(['git','worktree','add','--detach',str(ROOT),'c9c44913d443410ae4768b26faafd48fa367b2e2'],cwd=ORIGINAL,check=True)
for relative,expected in [('SslProto/src/external/ssl-game-controller','9b0765fe7a07a55124f6ee957d4559348462d227'),('SslProto/src/external/ssl-simulation-protocol','1e719a8d410cc84847ec69104da44fed13738291')]:
    dep=ORIGINAL/relative;target=ROOT/relative
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=dep).decode().strip()==expected
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=dep).strip()
    if target.exists():
        assert not list(target.iterdir());target.rmdir()
    target.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run(['cmd','/d','/c','mklink','/J',str(target),str(dep)],check=True)

D=Path('C:/Program Files/dotnet/dotnet.exe')
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT).decode().strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest={p:sha(ROOT/p) for p in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0') if p and (ROOT/p).is_file()}
state={'head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'cwd':str(ROOT),'git_status':git('status','--short'),'started_at':datetime.now(timezone.utc).isoformat(),'files_sha256':manifest,'source_fingerprint':hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest(),'commands':[]}
assert state['head']=='c9c44913d443410ae4768b26faafd48fa367b2e2'
env=dict(os.environ);env['PATH']=str(D.parent)+os.pathsep+env.get('PATH','');env['DOTNET_CLI_HOME']=str(O/'dotnet-home');env['DOTNET_CLI_TELEMETRY_OPTOUT']='1';env['DOTNET_SKIP_FIRST_TIME_EXPERIENCE']='1';env['DOTNET_GENERATE_ASPNET_CERTIFICATE']='false'
state['dependency_reuse']='Pinned and clean submodule sources reused through directory junctions; baseline build outputs are isolated.'
state['submodules_before']=git('submodule','status','--recursive')
assert all(line and line[0]!='-' and line[0]!='+' for line in state['submodules_before'].splitlines())
state['task_environment_overrides']={k:env[k] for k in ['DOTNET_CLI_HOME','DOTNET_CLI_TELEMETRY_OPTOUT','DOTNET_SKIP_FIRST_TIME_EXPERIENCE']};state['task_path_prefix']=str(D.parent)
def run(name,args):
 row={'name':name,'argv':list(map(str,args)),'cwd':str(ROOT),'head':state['head'],'source_fingerprint':state['source_fingerprint'],'started_at':datetime.now(timezone.utc).isoformat(),'stdout':str(O/(name+'.stdout.log')),'stderr':str(O/(name+'.stderr.log'))}
 with open(row['stdout'],'wb') as out,open(row['stderr'],'wb') as err:r=subprocess.run(row['argv'],cwd=ROOT,env=env,stdout=out,stderr=err)
 row.update(exit_code=r.returncode,result='passed' if r.returncode==0 else 'failed',finished_at=datetime.now(timezone.utc).isoformat());state['commands'].append(row)
 (O/'results.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8-sig');print(json.dumps({k:row[k] for k in ['name','result','exit_code']}),flush=True)
 return r.returncode
run('dotnet-info',[D,'--info'])
code=run('dotnet-test',[D,'test','Tracker/Tracker.Tests/Tracker.Tests.csproj','--logger','trx;LogFileName=dotnet-test.trx','--results-directory',O,'--diag',O/'vstest-diagnostics.log','--blame','-m:1','/nr:false','-bl:'+str(O/'dotnet-test.binlog')])
(O/'dotnet-test.exit-code').write_text(str(code)+'\n')
state['source_unchanged_during_validation']=all(sha(ROOT/p)==v for p,v in manifest.items());state['finished_at']=datetime.now(timezone.utc).isoformat()
state['diagnostics']=[{'path':str(p),'sha256':sha(p),'size':p.stat().st_size} for p in O.rglob('*') if p.is_file() and 'dotnet-home' not in p.parts and p.name!='results.json']
(O/'results.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8-sig')
assert state['source_unchanged_during_validation'];sys.exit(code)
