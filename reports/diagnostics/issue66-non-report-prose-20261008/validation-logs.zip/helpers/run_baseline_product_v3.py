﻿"""Execute the repository product gate with captured diagnostics."""
from pathlib import Path
import os,sys,json,hashlib,subprocess
from datetime import datetime,timezone
ROOT=Path('C:/Users/donabe/RemoteDesktopWorkspace/Duck-issue66-yomiyasu')
E=ROOT.parent/'Duck-issue66-prose-evidence-20261008'
O=E/'product-baseline-final';O.mkdir(exist_ok=False)
ORIGINAL=ROOT
ROOT=E/'baseline-product-source'
assert ROOT.is_dir()
D=Path('C:/Program Files/dotnet/dotnet.exe')
def git(*a):
 folder=ORIGINAL if a[0]=='submodule' else ROOT
 argv=['git',*a]
 if a[:2]==('status','--short'):argv.append('--ignore-submodules=all')
 return subprocess.check_output(argv,cwd=folder).decode().strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest={p:sha(ROOT/p) for p in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0') if p and (ROOT/p).is_file()}
state={'head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'cwd':str(ROOT),'git_status':git('status','--short'),'started_at':datetime.now(timezone.utc).isoformat(),'files_sha256':manifest,'source_fingerprint':hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest(),'commands':[]}
assert state['head']=='c9c44913d443410ae4768b26faafd48fa367b2e2'
env=dict(os.environ);env['PATH']=str(D.parent)+os.pathsep+env.get('PATH','');env['DOTNET_CLI_HOME']=str(O/'dotnet-home');env['DOTNET_CLI_TELEMETRY_OPTOUT']='1';env['DOTNET_SKIP_FIRST_TIME_EXPERIENCE']='1';env['DOTNET_GENERATE_ASPNET_CERTIFICATE']='false'
state['submodule_status_cwd']=str(ORIGINAL)
state['git_status_scope']='parent tracked content; submodule content is pinned and recorded from the reused original source directory'
assets=json.loads((ORIGINAL/'Tracker/Tracker.RuntimeHost/obj/project.assets.json').read_text(encoding='utf-8-sig'))
known_caches=[Path(n) for n in assets['packageFolders'] if (Path(n)/'microsoft.extensions.configuration.environmentvariables/10.0.7/lib/net10.0/Microsoft.Extensions.Configuration.EnvironmentVariables.dll').is_file()]
assert len(known_caches)==1,assets['packageFolders']
env['NUGET_PACKAGES']=str(known_caches[0])
state['nuget_packages']=str(known_caches[0])
state['dependency_reuse']='Pinned and clean submodule sources reused through directory junctions; baseline build outputs are isolated.'
state['submodules_before']=git('submodule','status','--recursive')
assert all(line and line[0]!='-' and line[0]!='+' for line in state['submodules_before'].splitlines())
state['task_environment_overrides']={k:env[k] for k in ['DOTNET_CLI_HOME','DOTNET_CLI_TELEMETRY_OPTOUT','DOTNET_SKIP_FIRST_TIME_EXPERIENCE']};state['task_path_prefix']=str(D.parent)
def run(name,args):
 row={'name':name,'argv':list(map(str,args)),'cwd':str(ROOT),'head':state['head'],'source_fingerprint':state['source_fingerprint'],'started_at':datetime.now(timezone.utc).isoformat(),'stdout':str(O/(name+'.stdout.log')),'stderr':str(O/(name+'.stderr.log'))}
 with open(row['stdout'],'wb') as out,open(row['stderr'],'wb') as err:r=subprocess.run(row['argv'],cwd=ROOT,env=env,stdout=out,stderr=err)
 row.update(exit_code=r.returncode,result='passed' if r.returncode==0 else 'failed',finished_at=datetime.now(timezone.utc).isoformat());state['commands'].append(row)
 (O/'results.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8-sig');print(json.dumps({k:row[k] for k in ['name','result','exit_code']}),flush=True)
 return r.returncode
run('dotnet-info',[D,'--info'])
code=run('dotnet-test',[D,'test','Tracker/Tracker.Tests/Tracker.Tests.csproj','--logger','trx;LogFileName=dotnet-test.trx','--results-directory',O,'--diag',O/'vstest-diagnostics.log','--blame','-m:1','/nr:false','-bl:'+str(O/'dotnet-test.binlog')])
(O/'dotnet-test.exit-code').write_text(str(code)+'\n')
state['source_unchanged_during_validation']=all(sha(ROOT/p)==v for p,v in manifest.items());state['finished_at']=datetime.now(timezone.utc).isoformat()
state['diagnostics']=[{'path':str(p),'sha256':sha(p),'size':p.stat().st_size} for p in O.rglob('*') if p.is_file() and 'dotnet-home' not in p.parts and p.name!='results.json']
(O/'results.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8-sig')
assert state['source_unchanged_during_validation'];sys.exit(code)
