﻿# -*- coding: utf-8 -*-
"""Issue #81/PR #84 のWindows有界実機受入。外部環境設定は変更しない。"""
import argparse, datetime, hashlib, json, os, pathlib, re, signal, subprocess, sys, time, uuid
WORK=pathlib.Path(r"C:\Users\donabe\RemoteDesktopWorkspace")
REPO=WORK/"Duck-pr84-issue81"
DOCKER=pathlib.Path(r"C:\Users\donabe\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe")
DOTNET=pathlib.Path(r"C:\Program Files\dotnet\dotnet.exe")
APPHOST=REPO/r"Testing\Duck.Testing.AppHost\bin\Debug\net10.0\Duck.Testing.AppHost.dll"
HEAD="e43cdd6e67efabac4e5de86af5b4b3f1b2ab021f"
ENGINE="5bc5ab8a-7340-47ba-8b7c-9f645375a54c"
RUNLABEL="com.ibis-ssl.duck.run-id"
ROLELABEL="com.ibis-ssl.duck.role"
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def call(args, timeout=7):
    return subprocess.run([str(a) for a in args],capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=timeout,stdin=subprocess.DEVNULL)
def docker(*args, timeout=7): return call([DOCKER,"--context","desktop-linux",*args],timeout)
def need(ok, msg):
    if not ok: raise RuntimeError(msg)
def save(path,data): path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def list_containers():
    p=docker("ps","-a","--no-trunc","--format","{{.ID}}|{{.Names}}")
    need(p.returncode==0,"docker ps: "+p.stderr[:300])
    return [{"id":t.split("|",1)[0],"name":t.split("|",1)[-1]} for t in p.stdout.splitlines() if "|" in t]
def engine():
    p=docker("info","--format","{{.ID}}")
    need(p.returncode==0,"docker info failure: "+p.stderr[:300])
    return p.stdout.strip()
def preflight():
    need(DOCKER.is_file() and DOTNET.is_file() and APPHOST.is_file(),"Missing program")
    g=call(["git","-C",REPO,"rev-parse","HEAD"])
    need(g.returncode==0 and g.stdout.strip()==HEAD,"HEAD mismatch")
    status=call(["git","-C",REPO,"status","--porcelain"])
    need(status.returncode==0 and not status.stdout.strip(),"Worktree is not clean")
    need(engine()==ENGINE,"Docker Engine mismatch")
    need(len(list_containers())==0,"Existing containers are not ours")
    for name in ("duck-issue81-refereedriver:c0d748e","duck-issue81-runtime:fe3eeef"):
        p=docker("image","inspect",name,"--format","{{.Id}}")
        need(p.returncode==0 and p.stdout.strip(),"Local image absent: "+name)
    digest=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    return {"head":HEAD,"dockerEngine":ENGINE,"apphostDllSha256":digest(APPHOST),
      "driverDllSha256":digest(REPO/r"Testing\Duck.Testing.RefereeDriver.Host\bin\Release\net10.0\publish\Duck.Testing.RefereeDriver.Host.dll"),
      "runtimeDllSha256":digest(REPO/r"Tracker\Tracker.RuntimeHost\bin\Release\net10.0\publish\Tracker.RuntimeHost.dll")}
def driver_id(runid):
    p=docker("ps","--no-trunc","--filter","label="+RUNLABEL+"="+runid,
             "--filter","label="+ROLELABEL+"=referee-driver","--format","{{.ID}}")
    if p.returncode: return None
    ids=[i for i in p.stdout.splitlines() if re.fullmatch(r"[0-9a-f]{64}",i)]
    if len(ids)!=1: return None
    ins=docker("inspect",ids[0],"--format","{{json .Config.Labels}}")
    if ins.returncode: return None
    try: labels=json.loads(ins.stdout)
    except ValueError: return None
    return ids[0] if labels.get(RUNLABEL)==runid and labels.get(ROLELABEL)=="referee-driver" else None
def probe(cid,runid):
    req='exec 3<>/dev/tcp/127.0.0.1/39110; printf "GET /health/referee HTTP/1.0\\r\\nHost: localhost\\r\\nConnection: close\\r\\n\\r\\n" >&3; cat <&3'
    row={"utc":now(),"runId":runid,"containerId":cid}
    try:
        r=docker("exec",cid,"/bin/bash","-c",req,timeout=4.5)
        row["dockerExit"]=r.returncode
        row["error"]=r.stderr[:180] if r.returncode else ""
        m=re.search(r"HTTP/1\.[01]\s+(\d{3})",r.stdout)
        row["httpStatus"]=int(m.group(1)) if m else None
        parts=re.split(r"\r?\n\r?\n",r.stdout,maxsplit=1)
        if len(parts)>1:
            try: row["body"]=json.loads(parts[1].strip())
            except ValueError: row["unparsedBody"]=parts[1][-200:]
    except Exception as ex: row["error"]=type(ex).__name__+":"+str(ex)[:220]
    return row
def execute():
    before=preflight()
    rid=uuid.uuid4().hex
    folder=WORK/("issue81-postfix-acceptance-"+rid)
    folder.mkdir(exist_ok=False)
    save(folder/"run-meta.safe.json",{"runId":rid,"startedUtc":now(),"preflight":before,
          "resources":["simulator","duck","game-controller","referee-driver"],"stopAfterSeconds":75,"stopWaitSeconds":25})
    print("RUN_ID="+rid+" RUN_DIR="+str(folder),flush=True)
    env=os.environ.copy()
    # DCP自身がdocker CLIをPATHで検出するため、子AppHostに限って既存Docker Desktop CLI場所を追加する。
    env["PATH"]=str(DOCKER.parent)+os.pathsep+env.get("PATH","")
    env["DOCKER_CONTEXT"]="desktop-linux"
    env.update({
      "Testing__GameControllerVisionOnly":"true",
      "Testing__IdentityControl__DesktopBridgeEnabled":"true",
      "Testing__IdentityControl__DockerContext":"desktop-linux",
      "Testing__IdentityControl__ExpectedEngineId":ENGINE,
      "Testing__IdentityControl__DockerExecutable":str(DOCKER),
      "Testing__IdentityControl__SafeTracePath":str(folder/"identity.safe.jsonl"),
      "Testing__Diagnostics__RunId":rid,
      "Testing__StackOwnership__LockPath":str(folder/"owned-stack.lock")})
    info={"runId":rid,"head":HEAD,"startedUtc":now(),"apphostPid":None,
          "apphostExit":None,"ctrlBreakSent":False,"forcedStop":False,
          "probes":0,"readySamples":0,"statuses":{},"observedContainers":[],
          "remainingContainers":[],"errors":[],"preflight":before}
    seen=set()
    p=None
    stdout=(folder/"apphost.stdout.log").open("w",encoding="utf-8")
    stderr=(folder/"apphost.stderr.log").open("w",encoding="utf-8")
    try:
        p=subprocess.Popen([str(DOTNET),str(APPHOST)],cwd=str(REPO),env=env,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
            stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
        info["apphostPid"]=p.pid
        print("APPHOST_PID="+str(p.pid),flush=True)
        begun=time.monotonic()
        with (folder/"health-probes.jsonl").open("w",encoding="utf-8") as logs:
            while time.monotonic()-begun<75:
                if p.poll() is not None:
                    info["errors"].append("AppHost exited before deadline")
                    break
                try:
                    for row in list_containers(): seen.add(row["id"])
                    cid=driver_id(rid)
                    if cid:
                        sample=probe(cid,rid)
                        logs.write(json.dumps(sample,ensure_ascii=False)+"\n")
                        logs.flush()
                        info["probes"]+=1
                        status=str(sample.get("httpStatus"))
                        info["statuses"][status]=info["statuses"].get(status,0)+1
                        body=sample.get("body")
                        if isinstance(body,dict) and sample.get("httpStatus")==200 and body.get("isReady") is True:
                            info["readySamples"]+=1
                    else: print("NO_OWNED_DRIVER elapsed="+str(round(time.monotonic()-begun)),flush=True)
                except Exception as ex:
                    info["errors"].append("probe "+type(ex).__name__+":"+str(ex)[:160])
                t=75-(time.monotonic()-begun)
                if t>0: time.sleep(min(2,t))
        if p.poll() is None:
            try:
                p.send_signal(signal.CTRL_BREAK_EVENT)
                info["ctrlBreakSent"]=True
                print("CTRL_BREAK_SENT",flush=True)
            except Exception as ex:
                info["errors"].append("CTRL_BREAK:"+str(ex)[:160])
            try: p.wait(timeout=25)
            except subprocess.TimeoutExpired:
                p.kill()
                info["forcedStop"]=True
                info["errors"].append("AppHost forced stop after CTRL_BREAK deadline")
                p.wait(timeout=5)
        info["apphostExit"]=p.returncode
    except Exception as ex:
        info["errors"].append("runner "+type(ex).__name__+":"+str(ex)[:250])
    finally:
        if p and p.poll() is None:
            p.kill()
            info["forcedStop"]=True
            try: p.wait(timeout=5)
            except subprocess.TimeoutExpired: info["errors"].append("AppHost still alive")
        if p: info["apphostExit"]=p.poll()
        stdout.close()
        stderr.close()
        try:
            need(engine()==ENGINE,"Engine changed after run")
            before_cleanup=list_containers()
            info["observedContainers"]=before_cleanup
            # 実行中に観測した同じRunIdラベルの資源だけを必要時に削除。
            for row in before_cleanup:
                if row["id"] not in seen: continue
                ins=docker("inspect",row["id"],"--format","{{json .Config.Labels}}")
                if ins.returncode: continue
                try: labels=json.loads(ins.stdout)
                except ValueError: continue
                if labels.get(RUNLABEL)==rid and labels.get(ROLELABEL) in ("duck","referee-driver"):
                    rm=docker("rm","-f",row["id"])
                    info.setdefault("cleanup",[]).append({"id":row["id"],"exit":rm.returncode})
            info["remainingContainers"]=list_containers()
        except Exception as ex: info["errors"].append("postcheck "+str(ex)[:250])
        info["endedUtc"]=now()
        save(folder/"process-result.safe.json",info)
    print("RESULT="+json.dumps({k:info[k] for k in
      ("runId","apphostPid","apphostExit","ctrlBreakSent","forcedStop",
       "probes","readySamples","statuses","remainingContainers","errors")},ensure_ascii=False),flush=True)
    return 0 if (info["apphostExit"]==0 and info["readySamples"]>0 and
      not info["forcedStop"] and not info["remainingContainers"] and not info["errors"]) else 2
if __name__=="__main__":
    parser=argparse.ArgumentParser()
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--preflight-only",action="store_true")
    group.add_argument("--run-once",action="store_true")
    args=parser.parse_args()
    try:
        if args.preflight_only:
            print("PREFLIGHT="+json.dumps(preflight(),ensure_ascii=False),flush=True)
            sys.exit(0)
        sys.exit(execute())
    except Exception as ex:
        print("FATAL="+type(ex).__name__+":"+str(ex),flush=True)
        sys.exit(3)
