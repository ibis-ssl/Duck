﻿# -*- coding: utf-8 -*-
"""既存の依存だけで対象文書を検査し、実行結果と原本の指紋を保存する。"""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

repo = Path.cwd()
evidence = Path(__file__).resolve().parent
phase = sys.argv[1]
out = evidence / ("docs-" + phase)
out.mkdir(exist_ok=False)
deps = repo.parent / "Duck-issue66-yomiyasu"
yomi = deps / "artifacts/issue66/yomiyasu"
docs = ["Tracker/Design/Testing/aspire-simulation-test-environment.md", "Tracker/Design/tasks-status.md"]
report = "reports/issue81-shared-trace-and-windows-acceptance-20261026.md"
files = docs + ([report] if (repo / report).exists() else [])
env = dict(os.environ, NODE_PATH=str(deps / "node_modules"), PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1")
records = []
manifest = {f: hashlib.sha256((repo / f).read_bytes()).hexdigest() for f in files}
for f in docs:
    (out / Path(f).name).write_bytes((repo / f).read_bytes())

def run(name, args):
    item = {"name": name, "args": [str(a) for a in args], "cwd": str(repo), "startedUtc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        p = subprocess.run(item["args"], capture_output=True, env=env, timeout=90)
        (out / (name + ".stdout.log")).write_bytes(p.stdout)
        (out / (name + ".stderr.log")).write_bytes(p.stderr)
        (out / (name + ".exit")).write_text(str(p.returncode) + "\n", encoding="utf-8")
        item["exit"] = p.returncode
    except Exception as exc:
        item.update(exit=None, error=repr(exc))
    records.append(item)
    (out / "commands.json").write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"name": name, "exit": item["exit"]}), flush=True)

run("tool-identity", ["git", "-C", yomi, "rev-parse", "HEAD"])
run("textlint", ["node", deps / "node_modules/textlint/bin/textlint.js", "--config", ".textlintrc.json", "--rulesdir", "tools/lint/scripts/textlint-rules", *docs])
# 設定や許可語処理は原本のまま、CLIの場所だけを既存依存へ差し替えた作業用コピーを使う。
wrapper = repo / "tools/lint/scripts/run-cspell-markdown.js"
source = wrapper.read_text(encoding="utf-8-sig")
old = 'const cspellCli = path.join(root, "node_modules", "cspell", "bin.mjs");'
assert source.count(old) == 1
replacement = 'const cspellCli = ' + json.dumps(str(deps / "node_modules/cspell/bin.mjs")) + ';'
adapted = out / "cspell-existing-deps.cjs"
adapted.write_text(source.replace(old, replacement), encoding="utf-8-sig")
run("cspell", ["node", adapted, *docs])
run("whitelist", [deps / ".venv/Scripts/python.exe", "-X", "utf8", "-B", "tools/lint/scripts/check-markdown-whitelist-sudachi.py", "--files", *docs])
for f in files:
    name = "yomiyasu-" + Path(f).stem
    run(name, [sys.executable, "-X", "utf8", "-B", yomi / "skills/yomiyasu/scripts/yomiyasu_lint.py", f, "--json", "--strict"])
    path = out / (name + ".stdout.log")
    if path.exists():
        try:
            result = json.loads(path.read_text(encoding="utf-8-sig"))
            print(json.dumps({"file": f, "score": result.get("score"), "findings": len(result.get("findings", [])), "severity": dict(collections.Counter(x.get("severity") for x in result.get("findings", [])))}), flush=True)
        except (ValueError, TypeError):
            pass
run("diff-check", ["git", "diff", "--check"])
assert manifest == {f: hashlib.sha256((repo / f).read_bytes()).hexdigest() for f in files}
(out / "manifest.json").write_text(json.dumps({"head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(), "files": manifest, "cspellOriginalSha256": hashlib.sha256(wrapper.read_bytes()).hexdigest(), "cspellAdapterSha256": hashlib.sha256(adapted.read_bytes()).hexdigest(), "dependencies": str(deps), "newDependenciesInstalled": False, "commands": records}, ensure_ascii=False, indent=2), encoding="utf-8")
