﻿"""検証のコマンド・版・出力・終了値を上書きせず保存する。"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

repo = Path.cwd()
label, *command = sys.argv[1:]
folder = repo / "artifacts/pr84-ci-followup-20261026" / label
folder.mkdir(parents=True, exist_ok=False)
def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)
def save(name, value):
    (folder / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
head = git("rev-parse", "HEAD").decode().strip()
diff = git("diff", "--binary", "HEAD")
(folder / "source.diff").write_bytes(diff)
manifest = {}
for name in ("scripts/tests/test_desktop_referee_acceptance.py", "scripts/verify_desktop_referee_acceptance.py", "Tracker/Tracker.Tests/VisionPacketCaptureTests.cs", "Tracker/Tracker.DebugHost/Tracking/DiagnosticsSampleLog.cs", "Tracker/Tracker.DebugHost/Tracking/TrackerPacketSnapshotLogReader.cs", "Tracker/Tracker.DebugHost/Tracking/TrackerSnapshotAlignmentLogReader.cs"):
    data = (repo / name).read_bytes()
    manifest[name] = hashlib.sha256(data).hexdigest()
    (folder / Path(name).name).write_bytes(data)
meta = {"argv":command, "cwd":str(repo), "host":os.environ.get("COMPUTERNAME"), "head":head,
        "diffSha256":hashlib.sha256(diff).hexdigest(), "sourceSha256":manifest,
        "startedUtc":datetime.datetime.now(datetime.timezone.utc).isoformat()}
save("command.json", meta)
env = os.environ.copy()
env["PYTHONUTF8"] = "1"
env["DOTNET_CLI_UI_LANGUAGE"] = "en-US"
with (folder / "stdout.log").open("wb") as out, (folder / "stderr.log").open("wb") as err:
    try:
        result = subprocess.run(command, cwd=repo, stdin=subprocess.DEVNULL, stdout=out, stderr=err, env=env)
        code = result.returncode
    except OSError as ex:
        err.write((type(ex).__name__ + ": " + str(ex)).encode("utf-8"))
        code = 127
meta.update(exitCode=code, finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
for name in ("stdout.log", "stderr.log"):
    meta[name + "Sha256"] = hashlib.sha256((folder / name).read_bytes()).hexdigest()
save("completion.json", meta)
(folder / "exit-code.txt").write_text(str(code) + "\n", encoding="ascii")
print(json.dumps({"stage":label,"head":head,"exitCode":code,"folder":str(folder)}), flush=True)
for name in ("stdout.log", "stderr.log"):
    print(name + "\n" + (folder / name).read_bytes().decode("utf-8",errors="replace")[-2500:])
sys.exit(code)
