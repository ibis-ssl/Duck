﻿"""今回のCI修正報告だけを既存ルールで全文検査する。"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
report = root / 'reports/issue81-pr84-ci-portability-fix-20261026.md'
body = report.read_text(encoding='utf-8-sig').encode('utf-8')
folder = root / 'artifacts/pr84-ci-followup-20261026' / sys.argv[1]
folder.mkdir(parents=True, exist_ok=False)
(folder / 'input.md').write_bytes(body)
deps = root.parent / 'Duck-issue66-yomiyasu'
env = os.environ.copy()
env['NODE_PATH'] = str(deps / 'node_modules')
env['PYTHONUTF8'] = '1'
commands = [
    ('textlint', ['node', str(deps / 'node_modules/textlint/bin/textlint.js'), '--config', '.textlintrc.json', '--rulesdir', 'tools/lint/scripts/textlint-rules', '--stdin', '--stdin-filename', 'pr84-ci-report.md'], True),
    ('cspell', ['node', 'artifacts/pr84-review-followup-20261026/docs-report-final/cspell-existing-deps.cjs', 'stdin://pr84-ci-report.md'], True),
    ('whitelist', [str(deps / '.venv/Scripts/python.exe'), '-X', 'utf8', '-B', 'tools/lint/scripts/check-markdown-whitelist-sudachi.py', '--stdin', 'pr84-ci-report.md'], True),
    ('yomiyasu', [sys.executable, '-X', 'utf8', '-B', str(deps / 'artifacts/issue66/yomiyasu/skills/yomiyasu/scripts/yomiyasu_lint.py'), str(report), '--json', '--strict'], False),
]
results = []
for name, argv, use_stdin in commands:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=root, env=env, input=body if use_stdin else None, capture_output=True)
    (folder / (name + '.stdout.log')).write_bytes(result.stdout)
    (folder / (name + '.stderr.log')).write_bytes(result.stderr)
    results.append({'name':name, 'argv':argv, 'startedUtc':started, 'exitCode':result.returncode,
                    'stdinSha256':hashlib.sha256(body).hexdigest() if use_stdin else None,
                    'stdoutSha256':hashlib.sha256(result.stdout).hexdigest(),
                    'stderrSha256':hashlib.sha256(result.stderr).hexdigest()})
    print(name, result.returncode)
    print(result.stdout.decode('utf-8',errors='replace')[-2000:])
    print(result.stderr.decode('utf-8',errors='replace')[-2000:])
summary = {'report':str(report), 'reportSha256':hashlib.sha256(report.read_bytes()).hexdigest(),
           'wholeBody':True, 'configurationChanged':False, 'dependenciesInstalled':False,
           'processOnlyNodePath':env['NODE_PATH'], 'commands':results}
(folder / 'documentation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sys.exit(0 if all(item['exitCode']==0 for item in results) else 1)
