﻿"""今回のCI修正の完了記録だけを公開用に採取する。"""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

root = Path.cwd()
source = root / 'artifacts/pr84-ci-followup-20261026'
target = root / 'reports/evidence/issue81-pr84-ci-portability-fix-20261026'
target.mkdir(parents=True, exist_ok=True)
stages = ['os-red', 'os-green', 'build', 'full-dotnet', 'final-python']
records = []
manifest = []
archive = target / 'diagnostics.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as bundle:
    for stage in stages:
        folder = source / stage
        record = json.loads((folder / 'completion.json').read_text(encoding='utf-8-sig'))
        record['stage'] = stage
        records.append(record)
        for path in sorted(folder.rglob('*')):
            if not path.is_file():
                continue
            data = path.read_bytes()
            name = path.relative_to(source).as_posix()
            publish = path.suffix != '.binlog' and not path.name.startswith('vstest')
            manifest.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                             'includedInPublicArchive': publish})
            # 実行環境を含み得る詳細診断は手元に保持し、公開物には指紋だけを残す。
            if publish:
                bundle.writestr(name, data)
counters = next(node.attrib for node in ET.parse(source / 'full-dotnet/full.trx').iter()
                if node.tag.split('}')[-1] == 'Counters')
result = {
    'technicalHead': '24fdc17472e58d31830bb10423f745ad5d7725c3',
    'baseHead': '6a32ff50af609a0665077d8161545a7117b136fd',
    'repository': 'ibis-ssl/Duck', 'pr': 84,
    'branch': 'task/issue81-aspire-desktop-bridge',
    'actualHost': 'FA780', 'sourceChanged': ['scripts/tests/test_desktop_referee_acceptance.py'],
    'productionPlatformGuardChanged': False, 'runtimeDockerExecuted': False,
    'runs': records, 'dotnetCounters': counters,
    'pythonTopLevelTests': 35, 'nestedFixtureCases': 9,
    'nestedFixtureCasesCountedAgain': False,
    'ciTechnicalHead': {
        'runId': 40319328371, 'headSha': '24fdc17472e58d31830bb10423f745ad5d7725c3',
        'testJob': 121559906238, 'testConclusion': 'success',
        'dotnetStep': 'success', 'pythonStep': 'success', 'linuxPublishStep': 'success',
        'packetFlowJob': 'skipped', 'fullStackJob': 'skipped'
    },
    'previousFailedCi': {'runId': 40300989815, 'headSha': '6a32ff50af609a0665077d8161545a7117b136fd',
                         'cause': 'WindowsRequired in 9 ImagePreflightTests on Linux'},
    'blockedOperation': {'tool': 'RemoteDesktopMCP.file_read',
        'path': 'reports/issue81-pr84-sharing-preflight-fixes-20261026.md',
        'result': 'OpenAI安全性チェックでブロック', 'retried': False,
        'approvalRequestedJst': '2026-10-26T21:01+09:00'},
    'archive': {'file': archive.name, 'bytes': archive.stat().st_size,
                'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'files': manifest
}
(target / 'verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8-sig')
print(json.dumps({'archive':result['archive'],'files':len(manifest),'dotnet':counters}, ensure_ascii=False))
