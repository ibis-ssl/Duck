﻿"""既存依存と既存規則で、変更文書の全文と台帳の追記を検査する。"""
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

root = Path.cwd()
area = root / 'artifacts/pr84-report-completion-20261026'
label = sys.argv[1]
baseline = label == 'baseline'
folder = area / ('docs-' + label)
folder.mkdir(exist_ok=False)
deps = root.parent / 'Duck-issue66-yomiyasu'
env = os.environ.copy()
env['NODE_PATH'] = str(deps / 'node_modules')
env['PYTHONUTF8'] = '1'
paths = ['reports/issue81-pr84-sharing-preflight-fixes-20261026.md',
         'Tracker/Design/tasks-status.md', 'Tracker/Design/phases-status.md']
rules = ['.textlintrc.json', '.textlintignore', 'cspell.config.jsonc',
         'tools/lint/markdown-whitelist.yaml', 'tools/lint/prh.yml',
         'tools/lint/markdown-targets.json', 'tools/lint/scripts/check-markdown-whitelist-sudachi.py']
sha = lambda data: hashlib.sha256(data).hexdigest()
results = []
inputs = []
for path in paths:
    source = root / path
    previous = area / (source.name + '.before')
    text = (previous if baseline else source).read_text(encoding='utf-8-sig')
    inputs.append((path, 'whole', text))
    if not baseline and path.startswith('Tracker/'):
        old = previous.read_text(encoding='utf-8-sig').splitlines(keepends=True)
        new = text.splitlines(keepends=True)
        added = ''.join(''.join(new[j1:j2]) for tag, _, _, j1, j2 in difflib.SequenceMatcher(None, old, new).get_opcodes() if tag in ('insert', 'replace'))
        inputs.append((path, 'added', added))
for path, scope, text in inputs:
    key = Path(path).stem + '-' + scope
    location = folder / key
    location.mkdir()
    body = text.encode('utf-8')
    input_path = location / 'input.md'
    input_path.write_bytes(body)
    virtual = key + '.md'
    commands = [
        ('textlint', ['node', str(deps/'node_modules/textlint/bin/textlint.js'), '--config', '.textlintrc.json', '--rulesdir', 'tools/lint/scripts/textlint-rules', '--stdin', '--stdin-filename', virtual], True),
        ('cspell', ['node', 'artifacts/pr84-review-followup-20261026/docs-report-final/cspell-existing-deps.cjs', 'stdin://' + virtual], True),
        ('whitelist', [str(deps/'.venv/Scripts/python.exe'), '-X', 'utf8', '-B', 'tools/lint/scripts/check-markdown-whitelist-sudachi.py', '--stdin', virtual], True),
        ('yomiyasu', [sys.executable, '-X', 'utf8', '-B', str(deps/'artifacts/issue66/yomiyasu/skills/yomiyasu/scripts/yomiyasu_lint.py'), str(input_path), '--json', '--strict'], False),
    ]
    for name, argv, stdin in commands:
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        value = subprocess.run(argv, cwd=root, env=env, input=body if stdin else None, capture_output=True)
        (location/(name+'.stdout.log')).write_bytes(value.stdout)
        (location/(name+'.stderr.log')).write_bytes(value.stderr)
        raw = (value.stdout + value.stderr).decode('utf-8', errors='replace')
        record = {'source':path, 'scope':scope, 'name':name, 'argv':argv, 'cwd':str(root),
                  'startedUtc':started, 'exitCode':value.returncode, 'inputSha256':sha(body),
                  'stdoutSha256':sha(value.stdout), 'stderrSha256':sha(value.stderr),
                  'logs':location.relative_to(root).as_posix()}
        if name == 'cspell':
            match = re.search(r'Issues found:\s*(\d+)', raw)
            record['issues'] = int(match[1]) if match else None
        if name == 'whitelist':
            record['issues'] = sum(line.startswith('- ') for line in raw.splitlines())
        if name == 'yomiyasu':
            try:
                parsed = json.loads(value.stdout)
                record.update(score=parsed['score'], issues=len(parsed['findings']))
            except (ValueError, KeyError):
                record['issues'] = None
        results.append(record)
        print(json.dumps({k:record.get(k) for k in ('source','scope','name','exitCode','issues','score')}, ensure_ascii=False), flush=True)
summary = {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),
           'baseline':baseline, 'configurationChanged':False, 'dependenciesInstalled':False,
           'processOnlyNodePath':env['NODE_PATH'], 'rulesSha256':{n:sha((root/n).read_bytes()) for n in rules},
           'wholeBodyViaStdin':True, 'yomiyasuUsesExactBodyCopy':True, 'results':results}
(folder/'documentation.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
# 既存の全文指摘を成功へ変換せず、各検査結果を保存する。
sys.exit(0 if all(r['exitCode']==0 for r in results) else 1)
